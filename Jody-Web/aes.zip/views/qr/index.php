<?php
/* @var $this yii\web\View */
?>
<h1>qr/index</h1>

<p>
    <code><?php $qrCode->render(); ?></code>.
</p>
