<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="body-content">

        <div class="row">

   

            <section id="latest-trips" class="col-md-6">
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h3 class="panel-title">Latest Finished Trips</h3>
                  </div>

                  <div class="panel-body">
                    
                    <div class="panel panel-default finished-trip">
                      <div class="panel-body">
                        
                        <div class="col-sm-6">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-infor.jpg"; ?>" alt="Infor Office" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-rw.jpg"; ?>" alt="->" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-edsa.jpg"; ?>" alt="Market Market" class="img-rounded">
                        </div>

                        <div class="col-sm-6">
                            <dl style="margin-bottom:0px">
                              <dt>Infor to Edsa</dt>
                              <dd style="font-size:0.8em">6:00 PM</dd>
                              <dd style="font-size:0.8em">Sir Jody</dd>
                            </dl>
                        </div>

                      </div>
                    </div>

                    <div class="panel panel-default finished-trip">
                      <div class="panel-body">
                        
                        <div class="col-sm-6">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-infor.jpg"; ?>" alt="Infor Office" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-rw.jpg"; ?>" alt="->" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-mrkt.jpg"; ?>" alt="Market Market" class="img-rounded">
                        </div>

                        <div class="col-sm-6">
                            <dl style="margin-bottom:0px">
                              <dt>Infor to Market Market</dt>
                              <dd style="font-size:0.8em">7:00 PM</dd>
                              <dd style="font-size:0.8em">Sir Jeff</dd>
                            </dl>
                        </div>

                      </div>
                    </div>

                    <div class="panel panel-default finished-trip">
                      <div class="panel-body">
                        
                        <div class="col-sm-6">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-edsa.jpg"; ?>" alt="Infor Office" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-rw.jpg"; ?>" alt="->" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-infor.jpg"; ?>" alt="Market Market" class="img-rounded">
                        </div>

                        <div class="col-sm-6">
                            <dl style="margin-bottom:0px">
                              <dt>Edsa to Infor</dt>
                              <dd style="font-size:0.8em">8:00 PM</dd>
                              <dd style="font-size:0.8em">Sir Jody</dd>
                            </dl>
                        </div>

                      </div>
                    </div>

                    <div class="panel panel-default finished-trip">
                      <div class="panel-body">
                        
                        <div class="col-sm-6">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-mrkt.jpg"; ?>" alt="Infor Office" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-rw.jpg"; ?>" alt="->" class="img-rounded">
                            <img src="<?= Yii::$app->request->baseUrl . "/images/rt/rt-infor.jpg"; ?>" alt="Market Market" class="img-rounded">
                        </div>

                        <div class="col-sm-6">
                            <dl style="margin-bottom:0px">
                              <dt>Market Market to Infor</dt>
                              <dd style="font-size:0.8em">7:30 PM</dd>
                              <dd style="font-size:0.8em">Sir Jeff</dd>
                            </dl>
                        </div>

                      </div>
                    </div>

                    <button class="btn btn-default" type="submit">Load More Trips</button>

                  </div>
                </div>
            </section>

            <sectionid ="summary-and-reports" class="col-md-6">
                <div class="panel panel-default">
              
                      <div class="panel-heading">
                        <h3 class="panel-title">Daily Summary</h3>
                      </div>

                      <div class="panel-body">

                        <div class="row">
                        
                            <div class="col-md-6">
                               <div class="hero-widget well well-sm">
                                    <div class="icon">
                                         <i class="glyphicon glyphicon-sunglasses"></i>
                                    </div>
                                    <div class="text">
                                        <var>1</var>
                                        <label class="text-muted">active drivers</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                               <div class="hero-widget well well-sm">
                                    <div class="icon">
                                         <i class="glyphicon glyphicon-transfer"></i>
                                    </div>
                                    <div class="text">
                                        <var>8</var>
                                        <label class="text-muted">routes</label>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="row">
                        
                            <div class="col-md-6">
                               <div class="hero-widget well well-sm">
                                    <div class="icon">
                                         <i class="glyphicon glyphicon-user"></i>
                                    </div>
                                    <div class="text">
                                        <var>1500</var>
                                        <label class="text-muted">employees</label>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                               <div class="hero-widget well well-sm">
                                    <div class="icon">
                                         <i class="glyphicon glyphicon-star"></i>
                                    </div>
                                    <div class="text">
                                        <var>20</var>
                                        <label class="text-muted">event logs</label>
                                    </div>
                                </div>
                            </div>

                        </div>

                      </div>
                </div>

                <div class="panel panel-default">
              
                      <div class="panel-heading">
                        <h3 class="panel-title">Report</h3>
                      </div>

                      <div class="panel-body">
                        
                        <div class="dropdown">
                          <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                            -Select a report-
                            <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                            <li><a href="#">Daily Trip Report</a></li>
                            <li><a href="#">Monthly Trip Stats</a></li>
                            <li><a href="#">Violator reports</a></li>
                          </ul>
                        </div>

                        <br/>

                        <button type="button" class="btn btn-primary">Load report</button>

                      </div>
                </div>
            </section>


        </div>

    </div>
</div>
