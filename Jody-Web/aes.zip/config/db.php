<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=sparksit_jody',
    'username' => 'sparksit_jody',
    'password' => 'sparksit_jody',
    'charset' => 'utf8',
];
